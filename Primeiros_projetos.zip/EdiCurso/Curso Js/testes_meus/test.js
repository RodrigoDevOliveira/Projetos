for(var c = 1;c<=10;c++){
  console.log(`Teste ${c}`)
}