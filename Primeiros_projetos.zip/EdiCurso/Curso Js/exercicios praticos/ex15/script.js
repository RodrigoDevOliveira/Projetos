function verificar() {
    var data = new Date()
    var ano = data.getFullYear()
    var fano = document.getElementById('txtano')
    var res = document.querySelector('div#res')
    if (fano.value.length == 0 || Number(fano.value) > ano) {
        window.alert('Preencha os espaços vazios!')
    }else {
        var fsex = document.getElementsByName('radsex')
        var idade = ano - Number(fano.value)
        var genero = ''
        var img = document.createElement('img')
        img.setAttribute('id', 'foto')
        if (fsex[0].checked) {
            genero = 'um '
            if (idade >= 0 && idade < 10) {
                //Criança
                img.setAttribute('src', '1.png')
                genero = 'uma Criança'
            }else if (idade < 21) {
                // Jovem
                img.setAttribute('src', '3.png')
                genero += 'Jovem'
            }else if (idade < 50) {
                // Adulto
                img.setAttribute('src', '5.png')
                genero += 'Adulto'
            }else {
                // Idoso
                img.setAttribute('src', '7.png')
                genero += 'Idoso'
            }
        }else if (fsex[1].checked){
            genero = 'uma '
            if (idade >= 0 && idade < 10) {
                genero += 'Criança'
                img.setAttribute('src', '2.png')

            }else if(idade < 21) {
                genero += 'Jovem'
                img.setAttribute('src', '4.png')
            }else if(idade < 50) {
                genero += 'Adulta'
                img.setAttribute('src', '6.png')
            }else {
                genero += 'Idosa'
                img.setAttribute('src', '8.png')
            }
        }
        res.style.textAlign = 'center'
        res.innerHTML = `Detectamos ${genero} com ${idade} anos .`
        res.appendChild(img)
    }

}