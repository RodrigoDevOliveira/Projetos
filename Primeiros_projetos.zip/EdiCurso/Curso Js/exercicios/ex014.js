var c = 1
console.log('Exemplo de While')
while (c <= 6){
    
    console.log('Tudo bem ?')
    c++
}


var c = 1
console.log('Exemplo de Do While')
do {    
    console.log(`Passou ${c}`)
    c++
}while (c <= 6)