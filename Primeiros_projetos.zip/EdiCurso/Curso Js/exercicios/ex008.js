var vel = 61
console.log (`A velocidade do seu carro é ${vel}Km/h!`)
if(vel > 60) {
    console.log(`A velocidade permitida nessa via é de 60km/h, por isso você foi MULTADO!`)
}
console.log('Dirija sempre usando cinto de segurança!')