var agora = new Date()
var hora = agora.getHours()
var min = agora.getMinutes()
var seg = agora.getSeconds()
console.log(`Agora são exatamente ${hora}:${min}:${seg}`)


if (hora >= 5 && hora < 12){
    console.log('Bom dia!')
}else if (hora >= 12 && hora <= 18){
    console.log('Boa tarde!')
}else {
    console.log('Boa noite!')
}